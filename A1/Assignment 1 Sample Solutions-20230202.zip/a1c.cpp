#include <filesystem>
#include <iomanip>
#include <iostream>
#include <regex>
#include <string>

int main(int argc, char *argv[])
{
  namespace fs = std::filesystem;
  using namespace std;

  if (argc != 2 && argc != 3)
  {
    cerr << "Usage: " << argv[0] << " <path> [<regex>]\n";
    return 1;
  }

  const char* re = ".*";
  if (argc == 3)
    re = argv[2];

  regex compiled_re(re);

  fs::path const base = argv[1];
  for (auto const& entry : 
    fs::recursive_directory_iterator(
      base,
      fs::directory_options::skip_permission_denied
    )
  )
  {
    smatch m;
    if (regex_match(entry.path().filename().native(), m, compiled_re))
    {
      string const s = entry.path().lexically_relative(base).native();
      auto const p = quoted(s);

      if (fs::is_symlink(entry))
        cout << "LINK: " << p << '\n';
      else if (fs::is_regular_file(entry))
        cout << "FILE: " << fs::file_size(entry) << ' ' << p << '\n';
      else if (fs::is_directory(entry))
        cout << "DIR: " << p << '\n';
      else
        cout << "OTHER: " << p << '\n';
    }
  }
}
